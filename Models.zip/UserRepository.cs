﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms; 
using WinFormsApp1.Helpers; 
using WinFormsApp1.Models;
using WinFormsApp1.Controllers;

namespace WinFormsApp1.Models
{
    public class UserRepository
    {
        public User? Login(string username, string password)
        {
            try
            {
                using var conn = ConnectDB.GetConnection();
                conn.Open();

                using var cmdUser = new NpgsqlCommand(@"
            SELECT id_user, nama_lengkap, username, password, no_telp, is_aktif 
            FROM kapten.users 
            WHERE username = @username AND password = @password AND is_aktif = true", conn);

                cmdUser.Parameters.AddWithValue("username", username);
                cmdUser.Parameters.AddWithValue("password", password);

                using var reader = cmdUser.ExecuteReader();
                if (!reader.Read()) return null; 

                int idUser = reader.GetInt32(0);
                string namaLengkap = reader.GetString(1);
                string uname = reader.GetString(2);
                string pass = reader.GetString(3);
                string? noTelp = reader.IsDBNull(4) ? null : reader.GetString(4);
                bool isAktif = reader.GetBoolean(5);
                reader.Close(); // Tutup reader user agar bisa query role

                // Ambil daftar role milik user tersebut
                List<Userrole> roles = new List<Userrole>();
                using var cmdRoles = new NpgsqlCommand(@"
            SELECT ur.id_user, ur.id_role, r.nama_role 
            FROM kapten.user_roles ur
            INNER JOIN kapten.roles r ON ur.id_role = r.id_role
            WHERE ur.id_user = @idUser", conn);
                cmdRoles.Parameters.AddWithValue("idUser", idUser);

                using var readerRoles = cmdRoles.ExecuteReader();
                while (readerRoles.Read())
                {
                    roles.Add(new Userrole(readerRoles.GetInt32(0), readerRoles.GetInt32(1), readerRoles.GetString(2)));
                }

                // Manfaatkan method bawaanmu untuk generate object sesuai Role-nya!
                return CreateUserByRoles(idUser, namaLengkap, uname, pass, noTelp, isAktif, roles);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eror Login: " + ex.Message, "Error Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private User CreateUserByRoles(int idUser, string namaLengkap, string username, string password, string? noTelp, bool isAktif, List<Userrole> roles)
        {
            var user = new User
            {
                IdUser = idUser,
                NamaLengkap = namaLengkap,
                Username = username,
                Password = password,
                NoTelp = noTelp,
                IsAktif = isAktif,
                Roles = roles ?? new List<Userrole>()
            };

            return user;
        }


        public bool Register(string namaLengkap, string username, string password, string? noTelp, string roleAwal)
        {
            using var conn = ConnectDB.GetConnection();
            conn.Open();
            using var trans = conn.BeginTransaction(); // Gunakan transaksi supaya aman (tabel user & user_roles terisi semua)
            try
            {
                using var cmdUser = new NpgsqlCommand(@"
            INSERT INTO kapten.users (nama_lengkap, username, password, no_telp, is_aktif) 
            VALUES (@nama, @username, @password, @noTelp, true) RETURNING id_user", conn);

                cmdUser.Parameters.AddWithValue("nama", namaLengkap);
                cmdUser.Parameters.AddWithValue("username", username);
                cmdUser.Parameters.AddWithValue("password", password);
                cmdUser.Parameters.AddWithValue("noTelp", (object?)noTelp ?? DBNull.Value);

                int newIdUser = Convert.ToInt32(cmdUser.ExecuteScalar());

                int idRole = 3; 
                if (roleAwal.Equals("petani", StringComparison.OrdinalIgnoreCase)) idRole = 2;
                else if (roleAwal.Equals("inspektor", StringComparison.OrdinalIgnoreCase)) idRole = 4;
                else if (roleAwal.Equals("admin", StringComparison.OrdinalIgnoreCase)) idRole = 1;

                using var cmdRole = new NpgsqlCommand(@"
            INSERT INTO kapten.user_roles (id_user, id_role) VALUES (@idUser, @idRole)", conn);
                cmdRole.Parameters.AddWithValue("idUser", newIdUser);
                cmdRole.Parameters.AddWithValue("idRole", idRole);

                cmdRole.ExecuteNonQuery();
                trans.Commit();
                return true;
            }
            catch (Exception ex)
            {
                trans.Rollback(); 
                MessageBox.Show("Gagal Register: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        public bool SoftDeleteUser(int idUser)
        {
            try
            {
                using var conn = ConnectDB.GetConnection();
                conn.Open();
                using var cmd = new NpgsqlCommand(@"
            UPDATE kapten.users 
            SET is_aktif = false 
            WHERE id_user = @id", conn);

                cmd.Parameters.AddWithValue("id", idUser);
                return cmd.ExecuteNonQuery() > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal menonaktifkan user: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
    } 
}